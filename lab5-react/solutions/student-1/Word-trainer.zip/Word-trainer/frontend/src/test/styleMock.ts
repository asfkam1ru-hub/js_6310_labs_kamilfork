const styles: Record<string, string> = {}

export default styles
