# Frontend — тренажёр иностранных слов

React + TypeScript приложение для изучения иностранных слов с колодами и flash-карточками.

## Скрипты

```bash
npm install
npm run dev
npm run build
npm run lint
npm run lint:fix
npm test
npm run test:coverage
```
